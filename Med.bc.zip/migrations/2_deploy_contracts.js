
var Platform = artifacts.require("./Platform.sol");

module.exports = function(deployer) {

  deployer.deploy(Platform);
};
